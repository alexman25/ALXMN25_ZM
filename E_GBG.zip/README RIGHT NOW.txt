The intended purpose of these patches are to free up generic tile space so that more shared tile graphics can be loaded at the same time, while still looking close to vanilla!

E_GBG.bps
  Every unique but visually identical tile has been flattened into one tile
  Breakable blocks use two tiles per frame instead of four
  Missile door flash uses Power Bomb hatch gfx
  One tile in the door opening/closing animation that uses only two pixels has been replaced with empty space

This'll free up about eight blocks, and more if you're smart

E_GBG_2.bps
  Same as previous patch, but Missle/Super/PB hatches use alternate palettes instead of different graphics.
  
Frees up roughly another three blocks of space!