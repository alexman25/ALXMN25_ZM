ABOUT Extra Slot Samus (ZM)
    This is an ESU mod which features Samus Aran from the Metroid series with her standard power suit graphic design seen in Metroid: Zero Mission

INSTALLATION
    Extra Slot Samus (ZM) should be ordered **above** Extra Character Slots Ultimate, Chao Pet, and presumably Extra Save Slots
    
ABILITIES
    Samus' control scheme is based on Sonic's but with some alterations.
    
    - Can not super peelout
    - Can not insta-shield
    - Can infinitely reuse mid-air abilities before touching the ground, such as shield powers and hyper form dashing
    - Bubble shield bounce does not cut Samus' X velocity, but will not bounce off from the ground (enemies are still fair game!)
    - When running at high enough speed, Samus enters Speed Booster mode, which can break enemies and monitors without curling into a ball, as well as deflect projectiles
    - Power sneakers allow for easy speed-boosting!
    - Samus has two jump types. The straight jump leaves Samus vulnerable if she jumps without pressing left or right, but extends her hitbox. The screw attack is done by jumping with left or right pressed, and will damage enemies and protect Samus from projectiles!
    - Samus can fire a beam from her arm cannon! Aim in any of the eight directions with the d-pad, then press the "R" button! Beware, however, as this costs two rings! If the target is hit successfully, you will gain an additional 200 points to ensure that your ring bonus is not compromised!
    - Respin! Samus can resume somersaulting at almost any point mid-air by tapping the jump button again
    
EXPLICITLY COMPATIBLE MODS
    - Extra Character Slots
        Obviously!
    - Extra Save Slots
        Samus should render fine in the menu!
    - Chao Pet
        Chao gets replaced by a metroid hatchling, only while playing as Samus

CREDITS
    - Coolfsta
        Sprite editing templates
    - AtomicRey
        Ray's Projectile Framework
    - Dynamic Lemons
        Recurl
    - CRaZyK15
        Chao pet
    - SlimSlamtheFlimFlam
        Metroid: Zero Mission Samus sprite sheet rips
	- TimerBunneh
		Helped me with snowboarding sprite issues
    - iCloudius, MiaCDi, Techncolour, HazelSpooder, Dynamic Lemons, RetroForever, A.riff7, Louplayer, Edition, LunarCryptik, Campbellsonic, |Emi|, Legobouwer9, MyDude, SyntaxTsundere, 1Funniman, Xtu_art, ChelseaCatGirl, E-122-Psi, MotorRoach, Bastian95, Fadeinside, Lave sIime, Veenee, Fabchaotix, Sotaknuck, JuanMXGalarza, スタ ーダスト, PhilAnimates
        For ESU, Extra Slot Mighty, Extra Slot Ray, and Extra Slot Amy
		
TO DO:
	- Give Hyper Samus the fully powered suit graphics
	- Turn ground rolling into the morph ball
	- Ending sprites
	- Make screw attack and speed booster able to break destructible walls
	
	Aside from that, the mod is pretty much done. I spent like four days on this. It was originally just gonna be a Sonic reskin, but then I decided to see if I could make it an extra slot. I was content with that, but then I decided to learn Lemon Script a bit so I could add custom abilities. If you want to use my mod for any purpose, or expand upon it, feel free, but please credit all of the people listed in the credits section, as they laid all of the ground work for me to build off from. Enjoy! 