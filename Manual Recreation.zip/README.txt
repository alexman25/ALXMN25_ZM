This is a painstaking recreation of the USA instruction manual for Metroid on the NES.

The goal was not to create an exact replica, but rather a "close enough" replica that will serve as a conveniently editable base for custom NEStroid hack manuals (or whatever other reason you may wish to edit it for). The finished product is very faithful, replicating the original manual to a high degree of accuracy.

NOTES: This slideshow was created in Google Slides, primarily using Firefox, at standard page view. Sorts Mill Goudy, Helvetica Neue, Roboto Condensed, M PLUS 1 Code, Courier New, Cabin Condensed, Arial, Arial Black, and Arial Narrow. The slideshow may display incorrectly if using a different browser, slideshow program (Power Point, LibreOffice, etc.), or if you are missing any of these fonts.

CREDITS

	BUILDING THE SLIDESHOW
		alexman25
		ransomw
		...and some other anonymous people who have not stepped forward
		
	SPRITE RIPPING/EDITING
		Mister Mike
		alexman25
		
	CONCEPT ART SOURCES
		Metroid Database
		Metroid Recon
			Gamehiker
			
If you contributed and wish to be put in the credits, please let me know on Discord! @fennekinn

And, yes, the error on page 35 is both intentional and included in the original manual